import 'dart:ui';

class AppColor{
  static const activeColor = Color(0xFF121212);
  static const itemColor = Color(0xFF8875FF);
}